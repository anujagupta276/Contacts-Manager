<?php
	require_once('connection.php');
	session_start();
	if(!isset($_SESSION['uname']))
		header("Location:login.php");
		
		
		
		
	// for admin's deatils		
	if(isset($_GET['email']) && isset($_POST['btn_update'])){
			 $email = $_GET['email'];
			 $fname = trim($_POST['fname'],' ');
		     $lname = trim($_POST['lname'],' ');
		     $mail = trim($_POST['email'],' ');
		     $password = trim($_POST['password'],' ');
			 
			 $sql = "UPDATE user SET fname ='$fname', lname='$lname', email = '$mail', password='$password' WHERE email = '$email'";
			 $res= mysql_query($sql);
			 
			 if($res)
			 	header('Location:admin.php');
			  else
			echo"<script>alert('Error in updation');</script>";
			 
	}
	?>



<html>
   
   <head>
      	<title>Admin</title>
      
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <script type="text/javascript" src="js/jquery.1.11.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/jquery-min.js"></script>
        
        <script type="text/javascript">
			
			
				  $(document).ready(function() {
					$("#btn1").click(function(){
						$("#f1").show();
						$("#f2").hide();
						$("#f3").hide();
						 
					});
					
					 $("#btn2").click(function(){
						$("#f1").hide();
						$("#f2").show();
						$("#f3").hide();
					});
					
					 $("#btn3").click(function(){
						$("#f1").hide();
						$("#f2").hide();
						$("#f3").show();
					});
				  });
		</script>
        
        
        
        
        
    </head>
    
    <body>
      
      
      <div class=" container-fluid">
      <div class="row" style="background-color:#000">
      	    
          <div class="col-md-4" style="color:#FFF; font-family:'Comic Sans MS', cursive; font-size:36px;">contactzilla</div>
          <div class="col-md-4 col-md-offset-4" style="color:#FFF;  padding-left:300px; padding-top:10px;">
                 
                        	<div class="dropdown">
                               <button class="btn  dropdown-toggle"  style="background-color:#000; color:#FFF;" data-toggle="dropdown"><?php echo $_SESSION['uname']; ?>
                           
							  <span class="caret"></span></button>
                              <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                <li role="presentation" id="btn2" ><a role="menuitem" href="#">My Account</a></li>
                                <li role="presentation"><a role="menuitem" href="logout.php">Logout</a></li>
                                
                              </ul>
                            </div>
  
          </div>
		
      </div>
     </div>
     
     <div class="container-fluid text-center">    
  	  <div class="row content">
         <div class="col-sm-2 sidenav" style=" background-color: #f1f1f1; height:100%; padding-top:20px;">  
                 <div class="btn-group-vertical">
                    <button type="button" class="btn btn-primary " id="btn1"> Home</button><br>
                    <button type="button" class="btn btn-primary" id="btn3"> All Users</button> 
                    </div>                            
        </div>
        
         <div class="col-sm-8 text-left" id="display" style=" background-color:#FFF; height:100%; padding-top:20px;">
		 	<div id="f1" class="page-header text-center">
                    <h1>Hello Admin</h1>      
             </div>            
            
            
             <div id="f2" style="display:none;">
				<?php
                    require_once('connection.php');
                     
                    $email = $_SESSION['email'];
                    $sql = "SELECT * FROM user WHERE email = '$email'";
                    $rs = mysql_query($sql);
                    $row = mysql_fetch_array($rs);
                ?>
                
                <div class="page-header">
                    <h1>Account Details</h1>      
                  </div>
                
               <form method="post" action="admin.php?email=<?php echo $row['email']?>" class="form col-md-12 center-block" role="form" style="width:600px; padding-left:190px;">
                    <div class="form-group ">
                        <label for="fname">First Name:</label> 
                        <input type="text" required class="form-control" id="fname" name="fname" value="<?php echo $row['fname']; ?>">                
                    </div>
                    <div class="form-group ">
                        <label for="lname">Last Name:</label> 
                        <input type="text" required class="form-control" id="lname" name="lname" value="<?php echo $row['lname']; ?>">                
                    </div> 
                    <div class="form-group ">
                        <label for="email">Email Address:</label> 
                        <input type="text" required class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>">                
                    </div>  
                    <div class="form-group ">
                        <label for="password">Password:</label> 
                        <input type="text" required class="form-control" id="password" name="password" value="<?php echo $row['password']; ?>">                
                    </div>
                    
                    <button type="submit" name="btn_update" class="btn  btn-primary">Save</button>&nbsp;
                    <button type="submit" name="btn_cancel" id="btn2" class="btn">cancel</button>                             
                </form>
     
           </div> 
           
           
           
           <div id="f3" style="display:none;">
       		<?php
				require_once('connection.php');
				 
				$email = $_SESSION['email'];
				$sql = "SELECT * FROM user where email<>'admin@gmail.com'";
				$rs = mysql_query($sql);
				//$row = mysql_fetch_array($rs);
				//print_r($row);
			?>
       
    <div class="page-header">
                <h1>Users</h1>      
      </div>
    
    <div class="panel-group" id="accordion">
    <?php 
	$i = 0;
	while($row = mysql_fetch_array($rs)){
		$i++;
	
	?>

    
    
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?=$i?>"><?php echo '<b>'.$row['fname'].'</b>'; ?></a>
          <a href="delete_users.php?email=<?php echo $row['email']; ?>" style="float:right;">delete</a>
        </h4>
      </div>
      <div id="collapse<?=$i?>" class="panel-collapse collapse">
        <div class="panel-body"> 
        	<table class="table" width="100px;">
            	<tr>
                	<td>First Name</td>
                    <td><?php echo $row['fname']; ?></td>
                </tr>
                <tr>
                	<td>Last Name</td>
                    <td><?php echo $row['lname']; ?></td>
                </tr>
                <tr>
                	<td>Email</td>
                    <td><?php echo $row['email']; ?></td>
                </tr>
                <tr>
                	<td>Password</td>
                    <td><?php echo $row['password']; ?></td>
                </tr>
            
            
            </table>
            
            <p style="font-family: 'MS Serif', 'New York', serif; font-size:18px;"><b><i>Saved Contacts :</i></b></p>
            
            <?php
				//require_once('connection.php');
				 
				$eemail = $row['email'];
				$sql1 = "SELECT * FROM contacts where umail = '$eemail'";
				$result = mysql_query($sql1);
				 
				//$row1 = mysql_fetch_array($result);
				//print_r($row1);
			?>
            
           
            <div class="panel-group" id="accordion1">
				<?php 
                $j = $i * 10;
                while($row1 = mysql_fetch_array($result)){
                    $j++;     
                ?>
                
                <div class="panel panel-default">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion<?=$i?>" href="#collapse<?=$j?>"><?php echo '<b>'.$row1['name'].'</b>'; ?></a>
                     </h4>
                  </div>
                   <div id="collapse<?=$j?>" class="panel-collapse collapse">
        			<div class="panel-body"> 
                    		<div class="col-md-8">
                    		<table class="table" width="100px;">
                            <tr>
                                <td>First Name</td>
                                <td><?php echo $row1['name']; ?></td>
                            </tr>
                            <tr>
                                <td>Mid Name</td>
                                <td><?php echo $row1['midname']; ?></td>
                            </tr>
                            <tr>
                                <td>Last Name</td>
                                <td><?php echo $row1['lastname']; ?></td>
                            </tr>
                            <tr>
                                <td>Email Id</td>
                                <td><?php echo $row1['email']; ?></td>
                            </tr>
                             <tr>
                                <td>Skype Id</td>
                                <td><?php echo $row1['skype']; ?></td>
                            </tr>
                             <tr>
                                <td>Contact No.</td>
                                <td><?php echo $row1['phone']; ?></td>
                            </tr>
                             <tr>
                                <td>Address</td>
                                <td><?php echo $row1['address']; ?></td>
                            </tr>
                        
                        
                        </table>
                    
                    </div>
                     <div class="col-md-4 text-center" style="padding-top:20px;">
                	 <img src="<?=$row1['image']?>" height='150px' width='150px' class=" img-circle" style="border-color: #F00; border-radius:10px; border: #CCC solid ;">
                  
              		</div>
                    
                    
                  
                  
                  	 </div>
                  	</div>
                    
                  </div>
               
                
                <?php } ?>
                </div>

            
            
            
            
            
        
  
        
        </div>
      </div>
    </div>
    
   
    
   <?php } ?>
  </div> 
  
       </div>
           
           
           
           
           
           
           
           
           
           
           
           
           
           
                
            
            
            
         </div>
         
         
         
         <div class="col-sm-2 sidenav" style=" background-color: #f1f1f1; height:100%; padding-top:20px;">           
        </div>
    
     
     </div>
     </div>
      

    
     
     
     
     
    </body>
    </html>
    
      