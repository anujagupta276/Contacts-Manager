<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
 
<script type="text/javascript" src="js/jquery.1.11.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

</head>

<body>

<form>
     <input type="text" />
      <input type="text" style="display:none;">
      <input type="password" name="pswd" id="password" maxlength="16" size="20" >
      
</form>
<!--
<form action="demo_form.asp" method="get" autocorrect="off" autocapitalize="off" autocomplete="off">
	<div class="form-group">
    	<div class="input-group">
        		<label for="uLogin" class="input-group-addon glyphicon glyphicon-user"></label>
                <input type="email"  class="form-control" name="txt" id="txt" placeholder="Email" autocomplete="false" />
        </div>
    </div>
    
    <div class="form-group">
    	<div class="input-group">
        		<label for="uPassword" class="input-group-addon glyphicon glyphicon-lock"></label>
                <input type="password" autocomplete="off"  class="form-control" name="pwd" id="pwd" placeholder="Password" />
        </div>
    </div>
 -->
</form>
</body>
</html>