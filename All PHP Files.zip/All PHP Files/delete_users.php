<?php
	 
	require_once('connection.php');
	if(isset($_GET['email'])){
			$email = $_GET['email'];
			$sql = "DELETE FROM user WHERE email = '$email' ";
			$res = mysql_query($sql);
			$sql1 = "DELETE FROM contacts WHERE umail = '$email' ";
			$res1 = mysql_query($sql1);
			if($res && $res1)
				header('Location:admin.php');
			else
				die('ERROR in deletion!');
			
			 }
			 
	else 
		die('cid is missing');
	?>