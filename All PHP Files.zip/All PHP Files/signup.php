<?php
	$error = '';
	require_once('connection.php');
	session_start();
	if(isset($_POST['btn_signup'])){
		$fname = trim($_POST['fname'],' ');
		$lname = trim($_POST['lname'],' ');
		$email = trim($_POST['email'],' ');
		$password = trim($_POST['password'],' ');
		
		$sql = "INSERT INTO user VALUES ('$fname','$lname','$email','$password') ";
		$result = mysql_query($sql);
		 
		
		 if($result){
			 	 
				header('Location:login.php');
				}
		 else
		 	header('Location:signup.php'); 
		 	die('failed to register');
				
		}
	
	
?>






<html>

<head>
<title>Sign Up</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link href="css/styles.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.1.11.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery-min.js"></script>

<script type="text/javascript">

		
		function dovalidation() {
					//alert('heya');
			
					var fname = document.getElementById('fname').value;
					var lname = document.getElementById('lname').value;
					var pass1 = document.getElementById("password").value;
					var pass2 = document.getElementById("confirm_password").value;
					pass1=pass1.trim(); 
					pass2=pass2.trim(); 
					
					 
					var reg_exp_alpha = /^[a-zA-Z ]+$/;
					 
					fname =fname.trim();
					if(fname == null || fname.length==0 || fname.match(reg_exp_alpha)== null){
							//alert ('empty first name');
							document.getElementById("1").innerHTML = "Invalid first name!";
							document.getElementById("1").style.color="red";
							document.getElementById("fname").focus();								
							return false;
							}
				
					lname =lname.trim();
					if(lname == null || lname.length==0 || lname.match(reg_exp_alpha)== null){
							//alert ('empty first name');
							document.getElementById("2").innerHTML = "Invalid Last name!";
							document.getElementById("2").style.color="red";
							document.getElementById("lname").focus();								
							return false;
							}
				
 
				if(pass1 == null || pass1.length < 8 ){
						document.getElementById("4").innerHTML = "Password too short !!";
						document.getElementById("4").style.color="red";
						document.getElementById("password").focus();								
						return false;
					}
									
				if (pass1 != pass2) {
					//alert("Passwords Do not match");
					document.getElementById("password").style.borderColor = "#E34234";
					document.getElementById("confirm_password").style.borderColor = "#E34234";
					document.getElementById("3").innerHTML = "Passwords do not match!";
					document.getElementById("3").style.color="red";
					document.getElementById("password").focus();								
					return false;
				
				}
				 
		}
		
		
	
			 
</script>

</head>

<body>

 
<div id="loginModal" class="modal show bg-danger" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="row"><h1><a href="index.php" style=" text-decoration:none; font-family:'Comic Sans MS', cursive; font-size:36px; padding-left:30px;">contactzilla</a></h1><div>


  <div class="modal-dialog">
  <div class="modal-content">
      <div class="modal-header">
          
          <h1 class="text-center">Sign Up</h1>
      </div>
      <div class="modal-body">
          <form class="form col-md-12 center-block" action="signup.php" method="post" onSubmit="return dovalidation()">
            <div class="form-group">          
              <input type="text" required  class="form-control input-lg" id="fname" name="fname" placeholder="First Name">
              <p id="1"></p>
            </div>
            <div class="form-group">          
              <input type="text" required  class="form-control input-lg" id="lname" name="lname" placeholder="Last Name">
              <p id="2"></p>

            </div>
            
            <div class="form-group">          
              <input type="email" required  class="form-control input-lg" name="email" placeholder="Email">
            </div>
            
            <div class="form-group">
             <input type="text" style="display:none;">
              <input type="password" required class="form-control input-lg" id="password" name="password" placeholder="Password" maxlength="12">
              <p id="4"></p>
              <p id="3"></p>


            </div>
            
             <div class="form-group">
             <input type="text" style="display:none;">
              <input type="password" required  class="form-control input-lg" id="confirm_password" name="confirm_password" placeholder="Re-Enter Password" maxlength="12">
              
            </div>
            
            <div class="form-group">
              <button type="submit" class="btn btn-primary btn-lg btn-block" name="btn_signup" id="btn_signup">Sign Up</button>
            </div>
          </form>
      </div>
      <div class="modal-footer">
          <div class="col-md-12">Already have a Contactzilla account?<a href="login.php"> Login Now</a></div>
         
          
		  </div>	
      </div>
  </div>
  </div>
</div>
	</body>
    
  </html>
  
  