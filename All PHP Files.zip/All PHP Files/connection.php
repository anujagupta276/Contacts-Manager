<?php
	$hostname = 'localhost';
	$username = 'root';
	$password = '';
	$database_name = 'cms';
	
	//$mysqlconn = new MySQLi($hostname, $username,$password,$database_name);

	$link = mysql_connect($hostname, $username,$password);
	//var_dump($link);

	$r=mysql_select_db($database_name);
	//var_dump($r);
	//if($mysqlconn->error == ""){
		//	echo "connected";
	//}
	//var_dump($mysqlconn);
	
	
	?>