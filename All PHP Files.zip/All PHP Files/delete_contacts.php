<?php
	 
	require_once('connection.php');
	if(isset($_GET['email'])){
			$email = $_GET['email'];
			$sql = "DELETE FROM contacts WHERE email = '$email' ";
			$res = mysql_query($sql);
			if($res)
				header('Location:home.php');
			else
				die('ERROR in deletion!');
			
			 }
			 
	else 
		die('cid is missing');
	?>