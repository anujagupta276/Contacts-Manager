<?php
	require_once('connection.php');
	session_start();
	if(!isset($_SESSION['uname']))
		header("Location:login.php");
		
	 
	 if(isset($_POST['btn_save'])){
		 $reg_exp_alpha = '/*[a-zA-Z]+$/';
		  $first = trim($_POST['fname'],' ');
		  $mid = $_POST['mname'];
		  $last = trim($_POST['lname'],' ');
		  $phone = trim($_POST['phone'],' ');
		  $address = trim($_POST['address'],' ');
		  $skype = trim($_POST['skype'],' ');
		  $mail = trim($_POST['mail'],' ');
		  $umail  = $_SESSION['email'];
		  
		 if(strlen($first)==0 || $first=='' || $first== NULL)
		  echo "<script>alert('firstname is invalid')</script>";
		  
		   if(strlen($last)==0 || $last=='' || $last== NULL)
		  echo "<script>alert('lastname is invalid')</script>";
		   if(strlen($phone)==0 || $phone=='' || $phone== NULL)
		  echo "<script>alert('phone no. is invalid')</script>";
		   if(strlen($address)==0 || $address=='' || $address== NULL)
		  echo "<script>alert('address is invalid')</script>";
		   if(strlen($skype)==0 || $skype=='' || $skype== NULL)
		  echo "<script>alert('skype id is invalid')</script>";
		   if(strlen($mail)==0 || $mail=='' || $mail== NULL)
		  echo "<script>alert('mail id is invalid')</script>";
		  
		  
		  
		if(isset($_FILES['image'])){
			
			    
			  $errors= array();
			  $file_name = $_FILES['image']['name'];
			  $file_size =$_FILES['image']['size'];
			  $file_tmp =$_FILES['image']['tmp_name'];
			  $file_type=$_FILES['image']['type'];
			  $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
			  
			  $expensions= array("jpeg","jpg","png");
			  
			  if(in_array($file_ext,$expensions)=== false){
				 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
			  }
			  
			  if($file_size > 2097152){
				 $errors[]='File size must be excately 2 MB';
			  }
			  
			 if(empty($errors)==true){
				 $path = 'contact_image/'.$first.'_'.$file_name;
				 move_uploaded_file($file_tmp,$path);
				 
			  }
              else{
				echo "<script>alert('error in image uploading');</script>";
				header('Location:home.php');
			  }
   }
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
		  
				
				
		$sql = "INSERT INTO contacts VALUES ('$umail','$first','$mid','$last','$phone','$address','$skype','$mail','$path') ";
		
		$result = mysql_query($sql);
		
		if($result)
			echo"<script>alert('Contact Added!!');</script>";
         
		else
			echo"<script>alert('ERROR! This Contact already exist!');</script>";
      
		
			}
			
			
// contact detils updation

if(isset($_POST['btn_contact_update'])){

		 $reg_exp_alpha = '/*[a-zA-Z]+$/';
		  $first = trim($_POST['fname'],' ');
		  $mid = $_POST['mname'];
		  $last = trim($_POST['lname'],' ');
		  $phone = trim($_POST['phone'],' ');
		  $address = trim($_POST['address'],' ');
		  $skype = trim($_POST['skype'],' ');
		  $mail = trim($_POST['mail'],' ');
		  $umail  = $_SESSION['email'];
		  $match = $_GET['email'];
		  
		   
		 if(strlen($first)==0 || $first=='' || $first== NULL)
		  echo "<script>alert('firstname is invalid')</script>";
		  
		   if(strlen($last)==0 || $last=='' || $last== NULL)
		  echo "<script>alert('lastname is invalid')</script>";
		   if(strlen($phone)==0 || $phone=='' || $phone== NULL)
		  echo "<script>alert('phone no. is invalid')</script>";
		   if(strlen($address)==0 || $address=='' || $address== NULL)
		  echo "<script>alert('address is invalid')</script>";
		   if(strlen($skype)==0 || $skype=='' || $skype== NULL)
		  echo "<script>alert('skype id is invalid')</script>";
		   if(strlen($mail)==0 || $mail=='' || $mail== NULL)
		  echo "<script>alert('mail id is invalid')</script>";
				
				
		//$sql = "INSERT INTO contacts VALUES ('$umail','$first','$mid','$last','$phone','$address','$skype','$mail') ";
		 $sql = "UPDATE contacts SET umail = '$umail',name ='$first', midname='$mid', lastname = '$last', phone = '$phone', address = '$address', skype ='$skype',email = '$mail' WHERE email = '$match'";
		$result = mysql_query($sql);
		
		if($result)
			  header('Location:home.php'); 
			         
		else
			 die('ERROR in updation!');
      
		
			}			
			
			
			
			
			
			
			
			
			
			
			
			
	// for user's deatils		
	if(isset($_GET['email']) && isset($_POST['btn_update'])){
			 $email = $_GET['email'];
			 $fname = trim($_POST['fname'],' ');
		     $lname = trim($_POST['lname'],' ');
		     $mail = trim($_POST['email'],' ');
		     $password = trim($_POST['password'],' ');
			 
			 $sql = "UPDATE user SET fname ='$fname', lname='$lname', email = '$mail', password='$password' WHERE email = '$email'";
			 $res= mysql_query($sql);
			 
			 if($res)
			 	header('Location:home.php');
			  else
			echo"<script>alert('Error in updation');</script>";
			 
	}
	
	

	 
	

 

?>

<html>
   
   <head>
      	<title>Welcome To Contactzilla</title>
      
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <script type="text/javascript" src="js/jquery.1.11.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/jquery-min.js"></script>
 <!--       <script type="text/javascript">
        	function showcontent(id){
					 
					document.getElementById(id).style.display="block";
					}-->
					
					
			<script type="text/javascript">
			
			
				  $(document).ready(function() {
					$("#btn1").click(function(){
						$("#f1").show();
						$("#f2").hide();
						$("#f3").hide();
						$("#f4").hide();
					});
					
					$("#btn2").click(function(){
						$("#f2").hide();
						$("#f1").hide();
						$("#f3").hide();
						$("#f4").show();
					});
					
					
					$("#btn3").click(function(){
						$("#f2").show();
						$("#f1").hide();
						$("#f3").hide();
						$("#f4").hide();
					});
					
					$("#btn4").click(function(){
						$("#f2").hide();
						$("#f1").hide();
						$("#f3").show();
						$("#f4").hide();
					});
					
					$("#btn9").click(function(){
						$("#f1").hide();						
						$("#f2").hide();
						$("#f3").hide();						
						$("#f4").hide();						
						$("#f5").show();						
						});
					
					 
				});
				
				
				function ValidateFileUpload() {
					 

					var  fuData = document.getElementById('image');
					var  FileUploadPath = fuData.value;
					 
					
					if (FileUploadPath == '') {
							document.getElementById("imagealert").innerHTML = "Please upload an image!";
							document.getElementById("imagealert").style.color="red";
							 							
							return false;						
					}
						 
					
					 else {
						var Extension = FileUploadPath.substring(FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
					
					
					
						if (Extension == "gif" || Extension == "png" || Extension == "bmp"
									|| Extension == "jpeg" || Extension == "jpg") {
					
					
								if (fuData.files && fuData.files[0]) {
					
									var size = fuData.files[0].size;
					
									if(size > 2097152){
										document.getElementById("imagealert").innerHTML = "Only Image till 2MB size is allowed!";
										document.getElementById("imagealert").style.color="red";
										return false;
									} 
								}
					
						} 
					
					
					else {
							document.getElementById("imagealert").innerHTML = "This file extension is not allowed!";
							document.getElementById("imagealert").style.color="red";
							return false;
						}
					}
				}
				
				
				
				
				
				 
				
				function dovalidation(){
					 
					var fname = document.getElementById('fname').value;
					var mname = document.getElementById('mname').value;
					var lname = document.getElementById('lname').value;
					var mail = document.getElementById('mail').value;
					var skype = document.getElementById('skype').value;
					var phone = document.getElementById('phone').value;
					var address = document.getElementById('address').value;
					var reg_exp_alpha = /^[a-zA-Z ]+$/;
					var reg_exp_mob =/^[0-9]{10}$/;
					var reg_exp_add = /^[0-9a-zA-Z, ]+$/;
					fname =fname.trim();
					if(fname == null || fname.length==0 || fname.match(reg_exp_alpha)== null){
							//alert ('empty first name');
							document.getElementById("1").innerHTML = "Invalid first name!";
							document.getElementById("1").style.color="red";
							document.getElementById("fname").focus();								
							return false;
							}
							
					if(  mname.match(reg_exp_alpha)== null){
							//alert ('empty first name');
							document.getElementById("5").innerHTML = "Invalid middle name!";
							document.getElementById("5").style.color="red";
							document.getElementById("mname").focus();								
							return false;
							}
							
							
							
 		
					lname =lname.trim();
					if(lname == null || lname.length ==0 ||  lname.match(reg_exp_alpha)== null){
							//alert ('empty  name');
							document.getElementById("2").innerHTML = "Invalid last name!";
							document.getElementById("2").style.color="red";
							document.getElementById("lname").focus();								
							return false;
							}
							
					phone = phone.trim();
					if(   phone.match(reg_exp_mob)== null){
							//alert ('empty first name');
							document.getElementById("3").innerHTML = "Invalid contact number!";
							document.getElementById("3").style.color="red";
							document.getElementById("phone").focus();								
							return false;
							}
							
							
					address =address.trim();
					if(address== null || address.length ==0 ||  address.match(reg_exp_add)== null){
							//alert ('empty first name');
							document.getElementById("4").innerHTML = "Invalid address!";
							document.getElementById("4").style.color="red";
							document.getElementById("address").focus();								
							return false;
							}
					
					
					skype =skype.trim();
					if(skype == null || skype.length ==0 ||  address.match(reg_exp_add)== null){
							//alert ('empty first name');
							document.getElementById("6").innerHTML = "Invalid skype Id!";
							document.getElementById("6").style.color="red";
							document.getElementById("skype").focus();								
							return false;
							}
					
					
				}	
   
        </script>
   </head>
   
   <body>
      
      
      <div class=" container-fluid">
      <div class="row" style="background-color:#000">
      	   <!--<div class=" col-md-4" style="color:#FFF; float:right"><h1>Welcome <?php echo $_SESSION['uname']; ?></h1> </div>
			<div class=" col-md-4"><h1><a href="#" style=" text-decoration:none; font-family:'Comic Sans MS', cursive; font-size:36px;">contactzilla</a></h1><div>
     	   -->
          <div class="col-md-4" style="color:#FFF; font-family:'Comic Sans MS', cursive; font-size:36px;">contactzilla</div>
          <div class="col-md-4 col-md-offset-4" style="color:#FFF;  padding-left:300px; padding-top:10px;">
                 
                        	<div class="dropdown">
                               <button class="btn  dropdown-toggle"  style="background-color:#000; color:#FFF;" data-toggle="dropdown"><?php echo $_SESSION['uname']; ?>
                           
							  <span class="caret"></span></button>
                              <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                <li role="presentation" id="btn4" ><a role="menuitem" href="#">My Account</a></li>
                                <li role="presentation"><a role="menuitem" href="logout.php">Logout</a></li>
                                
                              </ul>
                            </div>
                        
                        
                 
                  
          </div>
		
      </div>
      
 
      </div>
      
      <div class="container-fluid text-center">    
  	  <div class="row content">
     <div class="col-sm-2 sidenav" style=" background-color: #f1f1f1; height:100%; padding-top:20px;">
    				<div class="btn-group-vertical">
                    <button type="button" class="btn btn-primary " id="btn1" title="home"> Home</button><br>
                    <button type="button" class="btn btn-primary" id="btn2" title="show all contacts"> All Contacts</button> 
                    </div>       
    </div>
    
    
    <div class="col-sm-8 text-left" id="display" style=" background-color:#FFF; height:100%; padding-top:20px;"> 
       <div id="f1" class="jumbotron text-center" style="background-color:#FFF;" ><h1>Welcome to contactzilla<h1><p>we specialize in managing contacts</p></div>
       <div id="f2" style="display:none;">
       		<div class="page-header">
                <h1>Add Contact	</h1>      
              </div>
       		<form method="post" action="home.php" enctype="multipart/form-data" onSubmit="return dovalidation()" class="form col-md-12 center-block" role="form" style="width:600px; padding-left:190px;">
            	<div class="form-group ">
                	<label for="fname">First Name:</label> 
                    <input type="text" required class="form-control" id="fname" name="fname"> 
                    <p id="1"></p>
                </div>
                <div class="form-group">
                	<label for="mname">Middle Name:</label>
                    <input type="text" class="form-control" id="mname" name="mname"> 
                     <p id="5"></p> 

                </div>
                <div class="form-group">
                	<label for="lname">Last Name:</label>
                    <input type="text" required class="form-control" id="lname" name="lname"> 
                    <p id="2"></p>
                </div>
                <div class="form-group">
                	<label for="mail">Email Id:</label>
                    <input type="email" class="form-control"  id="mail" name="mail"> 
                </div>
                <div class="form-group">
                	<label for="skype">Skype Id:</label>
                    <input type="text" class="form-control" id="skype" name="skype">
                     <p id="6"></p> 
 
                </div>
                <div class="form-group">
                	<label for="phone">Contact No.:</label>
                    <input type="text" maxlength="10" class="form-control" id="phone" name="phone" >
                     <p id="3"></p> 
                </div>
                <div class="form-group">
                	<label for="address">Address :</label>
                   <textarea class="form-control" required rows="3" id="address" name="address"></textarea>
                    <p id="4"></p> 

                </div>
                 <div class="form-group">
                	<label for="image">Upload Image :</label>
                    <input type="file" name="image" id="image" size="2097152" onChange=" return ValidateFileUpload()">
                    <p id="imagealert"></p>
                   
                </div>
                
            	<button type="submit" name="btn_save" class="btn  btn-primary">Save</button>
            
            </form>
       
       
       
       </div>
       
       <div id="f3" style="display:none;">
       		<?php
				require_once('connection.php');
				 
				$email = $_SESSION['email'];
				$sql = "SELECT * FROM user WHERE email = '$email'";
				$rs = mysql_query($sql);
				$row = mysql_fetch_array($rs);
			?>
            
            <div class="page-header">
                <h1>Account Details</h1>      
              </div>
            
           <form method="post" action="home.php?email=<?php echo $row['email']?>" class="form col-md-12 center-block" role="form" style="width:600px; padding-left:190px;">
            	<div class="form-group ">
                	<label for="fname">First Name:</label> 
                    <input type="text" required class="form-control" id="fname" name="fname" value="<?php echo $row['fname']; ?>">                
                </div>
				<div class="form-group ">
                	<label for="lname">Last Name:</label> 
                    <input type="text" required class="form-control" id="lname" name="lname" value="<?php echo $row['lname']; ?>">                
                </div> 
				<div class="form-group ">
                	<label for="email">Email Address:</label> 
                    <input type="text" required class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>">                
                </div>  
                <div class="form-group ">
                	<label for="password">Password:</label> 
                    <input type="text" required class="form-control" id="password" name="password" value="<?php echo $row['password']; ?>">                
                </div>
                
                <button type="submit" name="btn_update" class="btn  btn-primary">Save</button>&nbsp;
                <button type="submit" name="btn_cancel" id="btn1" class="btn ">cancel</button>                             
            </form>
            
            
            
       
       
       
       
	   </div> 
       
        <div id="f4" style="display:none;">
       		<?php
				require_once('connection.php');
				 
				$email = $_SESSION['email'];
				$sql = "SELECT * FROM contacts WHERE umail = '$email'";
				$rs = mysql_query($sql);
				//$row = mysql_fetch_array($rs);
				//print_r($row);
			?>
       
    <div class="page-header">
                <h1>Contacts</h1>      
      </div>
    
    <div class="panel-group" id="accordion">
    <?php 
	$i = 0;
	while($row = mysql_fetch_array($rs)){
		$i++;
	
	?>

    
    
    <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?=$i?>" title=<?php echo $row['email']; ?> ><?php echo '<b>'.$row['name'].'</b>'; ?></a>
          <a href="delete_contacts.php?email=<?php echo $row['email']; ?>" style="float:right;" title="Do you want to delete this contact?">delete</a>
        </h4>
      </div>
      <div id="collapse<?=$i?>" class="panel-collapse collapse">
        <div class="panel-body"> 
        
        <form method="post" action="home.php?email=<?php echo $row['email']; ?>" enctype="multipart/form-data"  class="form col-md-12 center-block" role="form" >
            	<div class="col-md-4">
                <div class="form-group">
                	<label for="fname">First Name: </label> 
                    <input type="text" required class=" form-control" id="fname" name="fname" value="<?php echo $row['name']; ?>"> 
                    <p id="u1"></p>
                </div>
                <div class="form-group">
                	<label for="mname">Middle Name:</label>
                    <input type="text" class="form-control" id="mname" name="mname" value="<?php echo $row['midname']; ?>"> 
                     <p id="u2"></p> 

                </div>
                <div class="form-group">
                	<label for="lname">Last Name:</label>
                    <input type="text" required class="form-control" id="lname" name="lname" value="<?php echo $row['lastname']; ?>"> 
                    <p id="u3"></p>
                </div>
                <div class="form-group">
                	<label for="mail">Email Id:</label>
                    <input type="email" class="form-control"  id="mail" name="mail" value="<?php echo $row['email']; ?>"> 
                </div>
                
                </div>
                <div class="col-md-4">
                <div class="form-group">
                	<label for="skype">Skype Id:</label>
                    <input type="text" class="form-control" id="skype" name="skype" value="<?php echo $row['skype']; ?>">
                     <p id="u4"></p> 
 
                </div>
                <div class="form-group">
                	<label for="phone">Contact No.:</label>
                    <input type="text" maxlength="10" class="form-control" id="phone" name="phone" value="<?php echo $row['phone']; ?>">
                     <p id="u5"></p> 
                </div>
                <div class="form-group">
                	<label for="address">Address :</label>
                   <textarea class="form-control" required rows="3" id="address" name="address"><?php echo $row['address']; ?></textarea>
                    <p id="u6"></p> 

                </div>
    
            	<button type="submit" name="btn_contact_update" class="btn  btn-primary">update</button>
                
            </div>
             <div class="col-md-4 text-center" style="padding-top:20px;">
              		 
                	 <img src="<?=$row['image']?>" height='150px' width='150px' class=" img-circle" style="border-color: #F00; border-radius:10px; border: #CCC solid ;">
                 
              </div>
            
            </form>
        
        
        </div>
      </div>
    </div>
    
   
    
   <?php } ?>
  </div>
  
  <?php if($i == 0) { ?>
  <div class="col-md-12 text-center" style="font-size:24px; color:#00F; font-family:'Comic Sans MS', cursive;">No Contacts to show!</div> 
  <?php } ?>
  
       </div>
        
       
       
             
    </div>
    
    
    <div class="col-sm-2 sidenav" style=" background-color: #f1f1f1; height:100%; padding-top:20px;">
    	 
    	<button type="button" class="btn btn-primary " id="btn3" title="Add Contacts"> Add Contacts </button>
    </div>
    
    </div>
    </div>
    
   </body>
   
</html>
