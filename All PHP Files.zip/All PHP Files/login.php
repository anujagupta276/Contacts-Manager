<?php
	$error = '';
	require_once('connection.php');
	session_start();
	if(isset($_POST['btn_login'])){
		
		$email = trim($_POST['email'],' ');
		$password = $_POST['pwd'];
		
		$sql = "select * from user where email='$email' and password ='$password' ";
		$result = mysql_query($sql);
		$count = mysql_num_rows($result);
		
		if($count == 1){
				$row = mysql_fetch_array($result);
				 $_SESSION['uname'] = $row['fname'];
				 $_SESSION['email'] = $row['email'];
				 if($email == 'admin@gmail.com')
				 		header("Location:admin.php");
				 else
				 		header("Location:home.php");
				 }
		else{
				$error = "Invalid Email or Password!";
				}
		 
		}
	
	
?>




<html>

<head>
<title>Login</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link href="css/styles.css" rel="stylesheet">
<script type="text/javascript" src="js/jquery.1.11.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

</head>

<body>
<!--login modal-->

<div id="loginModal" class="modal show bg-danger" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="row"><h1><a href="index.php" style=" text-decoration:none; font-family:'Comic Sans MS', cursive; font-size:36px; padding-left:30px;">contactzilla</a></h1><div>
  <div class="modal-dialog">
  <div class="modal-content">
      <div class="modal-header">
           <h1 class="text-center">Login</h1>
      </div>
      <div class="modal-body">
      	<div  style="padding-left:20px; color:#F30;"><?php echo $error; ?></div><br>
          <form class="form col-md-12 center-block" method="post" action="<?php echo $_SERVER['PHP_SELF']?>" >
          	
            <div class="form-group">
               
              <input type="text"  class="form-control input-lg" id="email" name="email" placeholder="Email" readonly onfocus="this.removeAttribute('readonly');">
            </div>
            <div class="form-group">
             <input type="text" name="pwd1" id="pwd1" style="display:none;">
              <input type="password"  class="form-control input-lg" id="pwd" name="pwd" placeholder="Password" maxlength="12" readonly onfocus="this.removeAttribute('readonly');">
            </div>
            <div class="form-group">
              <button class="btn btn-primary btn-lg btn-block" id="btn_login" name="btn_login">Log In</button>
            </div>
          </form>
      </div>
      <div class="modal-footer">
          <div class="col-md-12"> Don't have a Contactzilla account?<a href="signup.php"> Sign Up Now</a></div>
         
          
		  </div>	
      </div>
  </div>
  </div>
</div>
	</body>
    
  </html>