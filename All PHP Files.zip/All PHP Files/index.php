<html>

<head>
<title>Contactzilla</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<script type="text/javascript" src="js/jquery.1.11.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<link rel="stylesheet" href="assets/demo.css">
<link rel="stylesheet" href="assets/header-login-signup.css">
<link href='http://fonts.googleapis.com/css?family=Cookie' rel='stylesheet' type='text/css'>

		
			<script type="text/javascript">
			
			
				  $(document).ready(function() {
					$("#btn1").click(function(){
						$("#f1").show();
						$("#f2").hide();
						$("#f3").hide();
						$("#f4").hide();
					});
					$("#btn2").click(function(){
						$("#f1").hide();
 						$("#f2").show();
						$("#f3").hide();
						$("#f4").hide();
					});
					
					$("#btn3").click(function(){
 					   $("#f1").hide();
 						$("#f2").hide();
						$("#f3").show();
						$("#f4").hide();
					});
					$("#btn4").click(function(){
 						$("#f1").hide();
 						$("#f2").hide();
						$("#f3").hide();
						$("#f4").show();
					});
					
				  });
				  </script>


</head>



<body>
	
     
     	<header class="header-login-signup navbar-fixed-top">

			<div class="header-limiter">

            <h1><a href="#" style="font-family:'Comic Sans MS', cursive; font-size:36px;">contactzilla</a></h1>
    
            <nav>
                <a href="#" id="btn1">Home</a>
                <a href="#" id="btn2">Features</a>
                <a href="#" id="btn3">About</a>
                <a href="#" id="btn4">Contact</a>
            </nav>
    
            <ul>
                <li><a href="login.php">Login</a></li>
                <li><a href="signup.php">Sign up</a></li>
            </ul>
    
        </div>
         

</header>
 
 
 
 <div class="container-fluid" id="f1" style="background-color:#FFF;">
 
<!-- <div class="row" style="height:5px; background-color:#F00;"></div>
--> <div class="row"> <img src="images/bg_original.jpg" width="1365px"></div>

   
 
<div class="row">
	<div class="col-md-12 text-primary" style=" font-family:Verdana, Geneva, sans-serif; font-size:40px; text-align:center; margin-top:20px;" >The Smart Address Book</div> 
	<div class="row" style="margin-top:150px; padding-left:100px;">
 		<div class="col-md-6"><img src="images/1.PNG"></div>
 		<div class="col-md-6" style="color:#666;" >
        	<div class="row"style="font-size:50px; padding-top:20px; padding-left:200px;"> easy</div>
            <div class="row" style="font-size:24px; padding-left:20px;"> contactzilla makes contact management a breeze</div><br>
            <div class="row" style="height:1px; margin-left:100px; width:300px; background-color:#CCC;"></div><br>
            <div class="row" style="padding-left:10px; padding-right:20px; font-size:20px; color:#CCC;">Manage all of your contacts from one place. Unify your address books and back up to a secure cloud.</div>
        </div>
    </div>
    
    <div class="row">
    		<div class="col-md-6"  style="color:#666;" >
            	<div class="row" style="font-size:50px; padding-top:50px; padding-left:200px;">convenient</div>
           		<div class="row" style="font-size:24px; padding-left:80px;"> Stay connected to your contacts anytime anywhere</div><br>
                <div class="row" style="height:1px; margin-left:150px; width:300px; background-color:#CCC;"></div><br>
                <div class="row" style="padding-left:50px; font-size:20px; color:#CCC;">Contactzilla works across multiple platforms and devices. You'll always have access to your contacts and calendars.</div>
            </div>	
    	 	<div class="col-md-6" style=" padding-left:150px; padding-top:20px;"><img src="images/2.JPG"></div>    
    </div>
 
 
 	<div class="row" style="margin-top:80px; padding-left:100px;">
 		<div class="col-md-6"><img src="images/3.JPG"></div>
 		<div class="col-md-6" style="color:#666;" >
        	<div class="row"style="font-size:50px; padding-top:20px; padding-left:200px;">updated</div>
            <div class="row" style="font-size:24px; padding-left:50px;"> contactzilla Keeps your contacts updated </div><br>
            <div class="row" style="height:1px; margin-left:100px; width:300px; background-color:#CCC;"></div><br>
            <div class="row" style="font-size:20px; padding-left:30px;padding-right:20px; color: #CCC;">Contactzilla keeps all your address books and devices automatically updated.</div>
        </div>
    </div>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <div class="row text-primary" style="background-color: #CCC; margin-top:30px; font-size:50px; font-family:'Times New Roman', Times, serif;" align="center">Get started with contactzilla for free!</div>
    
    <div style=" padding-left:200px;">
    	<div style="display:inline;"><img src="images/11.PNG"</div>
        <div style="display:inline;"><img src="images/5.PNG"</div>
    	<div style="display:inline;"><img src="images/6.PNG"</div>

    </div>
    
    <div class="row" style="padding-left:300px;">
    	<div class="btn btn-primary" align="center" style="font-size:28px; padding-left:50px; padding-right:50px;"><a href="signup.php" style="text-decoration:none;"><font color="#FFFFFF">Get started for free!</font></a></div>
    </div>
    
    
    
   
    
 
 </div>

</div>


</div>



</div>
</div>
 


<div class="row" style="background-color: #666; color:#FFF; margin-top:30px; padding-left:15px; height:50px;">
	
	<div class="col-md-4" style="padding-top:15px;">Copyright © 2016 Contactzilla . All Rights Reserved</div>
  
</div> 



<div id="f2" style="display:none;"> 
	<div class="row">
        <div class="col-md-12 text-center" style="padding-top:50px;"><h1>A Unified view of Contacts</h1></div>
         <div class="col-md-12 text-center">Everything you need to know about your business contacts is at your fingertips.</div>
        <div class="col-md-12" style="margin-left:290px; margin-top:50px;"><img src="images/f1.png" class="img-circle img-responsive" width="800px" height="500px" style="border:#333 solid 10px; border-radius:10px;"></div>

	</div>
    
    <div class="row">
        <div class="col-md-12 text-center" style="padding-top:100px;"><h1>A versatile way of sorting your stuff</h1></div>
         <div class="col-md-12 text-center">Categorize and label contacts or other records on various parameters.</div>
        <div class="col-md-12" style="margin-left:290px; margin-top:50px;"><img src="images/f2.png" class="img-circle img-responsive" width="800px" height="500px" style="border:#333 solid 10px; border-radius:10px;"></div>
		<div class="col-md-12 text-center" style="padding-top:100px;"><h1><strong>Experience the passion and spirit of Contactzilla</strong></h1></div>
         
	</div>
    
    <div class="row text-center" >
    	<div class="btn btn-primary" align="center" style="font-size:28px; padding-left:50px; padding-right:50px; margin-top:50px;"><a href="signup.php" style="text-decoration:none;"><font color="#FFFFFF">Sign Up For Contactzilla</font></a></div>
    </div>
    
    
    
    <div class="row" style="background-color: #666; color:#FFF; margin-top:30px; padding-left:15px; height:50px;">
	
	<div class="col-md-4" style="padding-top:15px;">Copyright © 2016 Contactzilla . All Rights Reserved</div>
  
</div>
    
    




</div>

<div id="f3" style="display:none;">
	<div class="row">
   	<div class="col-md-6 text-center" style="background-color: #FFF; font-size:16px;padding-left:20px; padding-right:20px;">
   			<div class=" jumbotron page-header text-center" style="background-color:#FFF; ">
                   <h1> Who is Contactzilla and what do we do?</h1>      
    		</div>
            <div>Contactzilla is the most powerful fully-connected contact management platform for professionals and enterprises that need to master their contacts and be awesome with people. Contactzilla’s cross-platform suite of Apps and APIs enhance contacts with 360-degree insights, while keeping them organized, synchronized, up-to-date, and safe.</div>
   </div>
   <div class="col-md-6" style="margin-top:100px; padding-left:30px;"><img src="images/aboutus.PNG" class="img-responsive"></div>
   </div>
   
   <div class="row">
   <div class="col-md-12 jumbotron text-center page-header"><h1>Contactzilla wasn't built in a day </h1><br><h3>Explore our journey through time.</h3>.</div>
   </div>
   
   <div class="row">
   <div class="col-md-12 text-center" style="font-size:18px; padding-left:200px; padding-right:200px; padding-top:30px; color: #999;">
   In 2010, Contactzilla launched its first contact management solution to 100 beta users and began a journey that would later lead the company to take on the challenge of fixing the world’s contact information problem. The grand vision of connecting all the people and companies in the world with accurate and complete contact information accelerated the company’s success and served a growing customer base with unique customer insights and contact intelligence that no other data company could offer. Today, Contactzilla manages billions of contact records and helps millions of professionals to be awesome with people through better contact management and customer insights.
   </div>
   </div>
   
   
      <div class="row" style="background-color: #666; color:#FFF; margin-top:30px; padding-left:15px; height:50px;">
	
	<div class="col-md-4" style="padding-top:15px;">Copyright © 2016 Contactzilla . All Rights Reserved</div>
  
	</div> 
   

</div>




<div id="f4" style="display:none;">
	<div class=" jumbotron page-header text-center">
                    <h1>Contact Us</h1>      
    </div>
    <div class="col-md-12 text-center" style="background-color: #FFF; font-size:16px;"><strong>If there is anything that you would like to talk to us about please get in touch using one of the methods below.</strong></div>
	<div class="page-header"></div>
    
    <div class="row" style="margin-top:100px;">
    	<div class="col-md-4 text-center">
        	<div style="font-size:36px;">Address </div>
            <div class="page-header"></div>
             <div style="font-family:'Times New Roman', Times, serif; font-size:20px;"> Contactzilla, Inc. <br> 1050 Enterprise Way <br>Sunnyvale, Mumbai 94089</div>   

        </div>
        <div class="col-md-4 text-center">
        	<div style="font-size:36px;">Phone/Fax </div>
            	<div class="page-header"></div>
            <div style="font-family:'Times New Roman', Times, serif; font-size:20px;">Voice: (103) 900-8400 <br> Fax: (103) 900-8600</div>   


        </div>
        <div class="col-md-4 text-center">
        	<div style="font-size:36px;">Email Contact </div>
            <div class="page-header"></div>
            <div style="font-family:'Times New Roman', Times, serif; font-size:20px;">Company Info: info@contactzilla.com <br> Press & Analysis: press@contactzilla.com<br>Partnerships: partners@contactzilla.com<br>Report Abuse: abuse@contactzilla.com</div>   

        </div>
    
  
    </div>
    
      <div class="row" style="background-color: #666; color:#FFF; margin-top:30px; padding-left:15px; height:50px;">
	
	<div class="col-md-4" style="padding-top:15px;">Copyright © 2016 Contactzilla . All Rights Reserved</div>
  
	</div> 
    
</div>


  
 











    



</body>
</html>