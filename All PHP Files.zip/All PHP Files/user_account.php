<?php
	require_once('connection.php');
	session_start();
	if(!isset($_SESSION['uname']))
		header("Location:login.php");
		
	 if(isset($_POST['btn_save'])){
		 $reg_exp_alpha = '/*[a-zA-Z]+$/';
		  $first = trim($_POST['fname'],' ');
		  $mid = $_POST['mname'];
		  $last = trim($_POST['lname'],' ');
		  $phone = trim($_POST['phone'],' ');
		  $address = trim($_POST['address'],' ');
		  $skype = trim($_POST['skype'],' ');
		  $mail = trim($_POST['mail'],' ');
		  $parent  = $_SESSION['uname'];
		  
		 if(strlen($first)==0 || $first=='' || $first== NULL)
		  echo "<script>alert('firstname is invalid')</script>";
		  
		   if(strlen($last)==0 || $last=='' || $last== NULL)
		  echo "<script>alert('lastname is invalid')</script>";
		   if(strlen($phone)==0 || $phone=='' || $phone== NULL)
		  echo "<script>alert('phone no. is invalid')</script>";
		   if(strlen($address)==0 || $address=='' || $address== NULL)
		  echo "<script>alert('address is invalid')</script>";
		   if(strlen($skype)==0 || $skype=='' || $skype== NULL)
		  echo "<script>alert('skype id is invalid')</script>";
		   if(strlen($mail)==0 || $mail=='' || $mail== NULL)
		  echo "<script>alert('mail id is invalid')</script>";
				
				
		$sql = "INSERT INTO contacts VALUES ('$parent','$first','$mid','$last','$phone','$address','$skype','$mail') ";
		
		$result = mysql_query($sql);
		
		if($result)
			echo"<script>alert('Contact Added!!');</script>";
         
		else
			echo"<script>alert('ERROR! This Contact already exist!');</script>";
      
		
		  
		  
			}		
	
	
	
	

 

?>

<html>
   
   <head>
      	<title>Welcome </title>
      
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <script type="text/javascript" src="js/jquery.1.11.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/jquery-min.js"></script>
 <!--       <script type="text/javascript">
        	function showcontent(id){
					 
					document.getElementById(id).style.display="block";
					}-->
					
					
			<script type="text/javascript">
			
			
				  $(document).ready(function() {
					$("#btn1").click(function(){
						$("#f1").show();
						$("#f2").hide();
						
					});
					
					$("#btn2").click(function(){
						$("#f2").show();
						$("#f1").hide();
						
					});
					 
				});
				
				function dovalidation(){
					var fname = document.getElementById('fname').value;
					var mname = document.getElementById('mname').value;
					var lname = document.getElementById('lname').value;
					var mail = document.getElementById('mail').value;
					var skype = document.getElementById('skype').value;
					var phone = document.getElementById('phone').value;
					var address = document.getElementById('address').value;
					var reg_exp_alpha = /^[a-zA-Z ]+$/;
					var reg_exp_mob =/^[0-9]{10}$/;
					var reg_exp_add = /^[0-9a-zA-Z ]+$/;
					fname =fname.trim();
					if(fname == null || fname.length==0 || fname.match(reg_exp_alpha)== null){
							//alert ('empty first name');
							document.getElementById("1").innerHTML = "Invalid first name!";
							document.getElementById("1").style.color="red";
							document.getElementById("fname").focus();								
							return false;
							}
							
					if(  mname.match(reg_exp_alpha)== null){
							//alert ('empty first name');
							document.getElementById("5").innerHTML = "Invalid middle name!";
							document.getElementById("5").style.color="red";
							document.getElementById("mname").focus();								
							return false;
							}
							
							
							
 		
					lname =lname.trim();
					if(lname == null || lname.length ==0 ||  lname.match(reg_exp_alpha)== null){
							//alert ('empty first name');
							document.getElementById("2").innerHTML = "Invalid last name!";
							document.getElementById("2").style.color="red";
							document.getElementById("lname").focus();								
							return false;
							}
							
					phone = phone.trim();
					if(   phone.match(reg_exp_mob)== null){
							//alert ('empty first name');
							document.getElementById("3").innerHTML = "Invalid contact number!";
							document.getElementById("3").style.color="red";
							document.getElementById("phone").focus();								
							return false;
							}
							
							
					address =address.trim();
					if(address== null || address.length ==0 ||  address.match(reg_exp_add)== null){
							//alert ('empty first name');
							document.getElementById("4").innerHTML = "Invalid address!";
							document.getElementById("4").style.color="red";
							document.getElementById("address").focus();								
							return false;
							}
					
					
					skype =skype.trim();
					if(skype == null || skype.length ==0 ||  address.match(reg_exp_add)== null){
							//alert ('empty first name');
							document.getElementById("6").innerHTML = "Invalid skype Id!";
							document.getElementById("6").style.color="red";
							document.getElementById("skype").focus();								
							return false;
							}
					
					
				}	
   
        </script>
   </head>
   
   <body>
     <!-- <h1>Welcome <?php echo $_SESSION['uname']; ?></h1> 
      <h2><a href = "logout.php">log Out</a></h2>-->
      
      <div class=" container-fluid">
      <div class="row" style="background-color:#000">
      	   <!--<div class=" col-md-4" style="color:#FFF; float:right"><h1>Welcome <?php echo $_SESSION['uname']; ?></h1> </div>
			<div class=" col-md-4"><h1><a href="#" style=" text-decoration:none; font-family:'Comic Sans MS', cursive; font-size:36px;">contactzilla</a></h1><div>
     	   -->
          <div class="col-md-4" style="color:#FFF; font-family:'Comic Sans MS', cursive; font-size:36px;">contactzilla</div>
          <div class="col-md-4 col-md-offset-4" style="color:#FFF;  padding-left:300px; padding-top:10px;">
                 
                        	<div class="dropdown">
                               <button class="btn  dropdown-toggle"  style="background-color:#000; color:#FFF;" data-toggle="dropdown"><?php echo $_SESSION['uname']; ?>
                           
							  <span class="caret"></span></button>
                              <ul class="dropdown-menu" role="menu" aria-labelledby="menu1">
                                <li role="presentation"><a role="menuitem" href="#">My Account</a></li>
                                <li role="presentation"><a role="menuitem" href="logout.php">Logout</a></li>
                                
                              </ul>
                            </div>
                        
                        
                 
                  
          </div>
		
      </div>
      
<!--      <div class="row" style="background-color:#FFF;">
      	<div class="col-md-4 " style=" height:400px; background-color: #CCC;">
        		
        		 <!--<div class="btn btn-primary btn-block">Home</div>
        		 <div class="btn btn-info  btn-block">Contacts</div>
                 <div class="btn-group">
                 	<button type="button" class="btn btn-primary">sony</button>
                 	<button type="button" class=" btn btn-primary dropdown-toggle" data-toggle="dropdown">
                    <span class="caret"></span></button>
                    </button> 
                    <ul class="dropdown-menu" role="menu">
                    	<li><a href="#">tablet</a></li>
                        <li><a href="#">nino</a></li>
                    </ul>
                 </div>
                 <div class=" btn-group btn-group-vertical"> 
                     <a href="#" class="btn btn-primary "> btn1</a>
                      <a href="#" class="btn btn-primary"> btn2</a>
                     <a href="#" class="btn btn-primary"> btn3</a>
                 </div> 
                 
                 <div class="list-group">
                 	<a href="#" class="list-group-item  active">home</a>
                 	<a href="#" class="list-group-item">Contact</a>
                 </div>
                 
        </div>
      </div>-->
      </div>
      
      <div class="container-fluid text-center">    
  	  <div class="row content">
     <div class="col-sm-2 sidenav" style=" background-color: #f1f1f1; height:100%; padding-top:20px;">
    				<div class="btn-group-vertical">
                    <button type="button" class="btn btn-primary " id="btn1"> Home</button><br>
                    <button type="button" class="btn btn-primary" id="btn3"> All Contacts</button> 
                    </div>       
    </div>
    
    
    <div class="col-sm-8 text-left" id="display" style=" background-color:#FFF; height:100%; padding-top:20px;"> 
       <div id="f1" class="jumbotron text-center" style="background-color:#FFF;" ><h1>Welcome to contactzilla<h1><p>we specialize in managing contacts</p></div>
       <div id="f2" style="display:none;">
       		<div class="page-header">
                <h1>Add Contact	</h1>      
              </div>
       		<form method="post" action="home.php" enctype="multipart/form-data" onSubmit="return dovalidation()" class="form col-md-12 center-block" role="form" style="width:600px; padding-left:190px;">
            	<div class="form-group ">
                	<label for="fname">First Name:</label> 
                    <input type="text" required class="form-control" id="fname" name="fname"> 
                    <p id="1"></p>
                </div>
                <div class="form-group">
                	<label for="mname">Middle Name:</label>
                    <input type="text" class="form-control" id="mname" name="mname"> 
                     <p id="5"></p> 

                </div>
                <div class="form-group">
                	<label for="lname">Last Name:</label>
                    <input type="text" required class="form-control" id="lname" name="lname"> 
                    <p id="2"></p>
                </div>
                <div class="form-group">
                	<label for="mail">Email Id:</label>
                    <input type="email" class="form-control"  id="mail" name="mail"> 
                </div>
                <div class="form-group">
                	<label for="skype">Skype Id:</label>
                    <input type="text" class="form-control" id="skype" name="skype">
                     <p id="6"></p> 
 
                </div>
                <div class="form-group">
                	<label for="phone">Contact No.:</label>
                    <input type="text" maxlength="10" class="form-control" id="phone" name="phone" >
                     <p id="3"></p> 
                </div>
                <div class="form-group">
                	<label for="address">Address :</label>
                   <textarea class="form-control" required rows="3" id="address" name="address"></textarea>
                    <p id="4"></p> 

                </div>
                 <div class="form-group">
                	<label for="image">Upload Image :</label>
                    <input type="file" name="image" id="image">
                   
                </div>
                
            	<button type="submit" name="btn_save" class="btn  btn-primary">Save</button>
            
            </form>
       
       
       
       </div>
    </div>
    
    
    <div class="col-sm-2 sidenav" style=" background-color: #f1f1f1; height:100%; padding-top:20px;">
    	 
    	<button type="button" class="btn btn-primary " id="btn2"> Add Contacts </button>
    </div>
    
    </div>
    </div>
    
   </body>
   
</html>




